// BlueprintGeneratedClass CommMenuOption1ActionTraits.CommMenuOption1ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCommMenuOption1ActionTraits_C : UActionTraits {
};

