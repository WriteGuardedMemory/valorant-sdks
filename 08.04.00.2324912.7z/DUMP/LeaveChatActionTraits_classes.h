// BlueprintGeneratedClass LeaveChatActionTraits.LeaveChatActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct ULeaveChatActionTraits_C : UActionTraits {
};

