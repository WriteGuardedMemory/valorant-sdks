// ScriptStruct RemoteControlCommon.RCPropertyContainerKey
// Size: 0x0c (Inherited: 0x00)
struct FRCPropertyContainerKey {
	struct FName ValueTypeName; // 0x00(0x0c)
};

