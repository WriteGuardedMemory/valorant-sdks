// BlueprintGeneratedClass BPAresClientGameInstance.BPAresClientGameInstance_C
// Size: 0x868 (Inherited: 0x868)
struct UBPAresClientGameInstance_C : UAresClientGameInstance {
};

