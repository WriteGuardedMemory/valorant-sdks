// BlueprintGeneratedClass InspectActionTraits.InspectActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UInspectActionTraits_C : UActionTraits {
};

