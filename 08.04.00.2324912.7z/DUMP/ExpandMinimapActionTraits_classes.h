// BlueprintGeneratedClass ExpandMinimapActionTraits.ExpandMinimapActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UExpandMinimapActionTraits_C : UActionTraits {
};

