// BlueprintGeneratedClass ObserverFollowPrevActionTraits.ObserverFollowPrevActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UObserverFollowPrevActionTraits_C : UActionTraits {
};

