// BlueprintGeneratedClass MoveUpActionTraits.MoveUpActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UMoveUpActionTraits_C : UActionTraits {
};

