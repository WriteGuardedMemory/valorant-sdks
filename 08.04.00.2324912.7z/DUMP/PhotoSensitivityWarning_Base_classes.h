// WidgetBlueprintGeneratedClass PhotoSensitivityWarning_Base.PhotoSensitivityWarning_Base_C
// Size: 0x2e0 (Inherited: 0x2c8)
struct UPhotoSensitivityWarning_Base_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)
	struct FMulticastInlineDelegate OnUserDismiss; // 0x2d0(0x10)

	void Construct(); // Function PhotoSensitivityWarning_Base.PhotoSensitivityWarning_Base_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x4125d60
	void OnDismiss(); // Function PhotoSensitivityWarning_Base.PhotoSensitivityWarning_Base_C.OnDismiss // (BlueprintCallable|BlueprintEvent) // @ game+0x4125d60
	void ExecuteUbergraph_PhotoSensitivityWarning_Base(int32_t EntryPoint); // Function PhotoSensitivityWarning_Base.PhotoSensitivityWarning_Base_C.ExecuteUbergraph_PhotoSensitivityWarning_Base // (Final|UbergraphFunction) // @ game+0x4125d60
	void OnUserDismiss__DelegateSignature(); // Function PhotoSensitivityWarning_Base.PhotoSensitivityWarning_Base_C.OnUserDismiss__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x4125d60
};

