// BlueprintGeneratedClass GamepadSprayCommWheelActionTraits.GamepadSprayCommWheelActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UGamepadSprayCommWheelActionTraits_C : UActionTraits {
};

