// WidgetBlueprintGeneratedClass SelfClosingConfirmationModal.SelfClosingConfirmationModal_C
// Size: 0x518 (Inherited: 0x510)
struct USelfClosingConfirmationModal_C : UConfirmationModal_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)

	void Construct(); // Function SelfClosingConfirmationModal.SelfClosingConfirmationModal_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x4125d60
	void OnAnyModalButtonPressed(); // Function SelfClosingConfirmationModal.SelfClosingConfirmationModal_C.OnAnyModalButtonPressed // (BlueprintCallable|BlueprintEvent) // @ game+0x4125d60
	void ExecuteUbergraph_SelfClosingConfirmationModal(int32_t EntryPoint); // Function SelfClosingConfirmationModal.SelfClosingConfirmationModal_C.ExecuteUbergraph_SelfClosingConfirmationModal // (Final|UbergraphFunction) // @ game+0x4125d60
};

