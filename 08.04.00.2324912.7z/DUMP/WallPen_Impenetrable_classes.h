// BlueprintGeneratedClass WallPen_Impenetrable.WallPen_Impenetrable_C
// Size: 0x48 (Inherited: 0x48)
struct UWallPen_Impenetrable_C : UAresWallPenetration {
};

