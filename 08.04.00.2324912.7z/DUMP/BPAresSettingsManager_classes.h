// BlueprintGeneratedClass BPAresSettingsManager.BPAresSettingsManager_C
// Size: 0x470 (Inherited: 0x470)
struct UBPAresSettingsManager_C : UAresSettingsManager {
};

