// Class WwiseSimpleExternalSource.WwiseExternalSourceSettings
// Size: 0x98 (Inherited: 0x30)
struct UWwiseExternalSourceSettings : UObject {
	struct FSoftObjectPath MediaInfoTable; // 0x30(0x20)
	struct FSoftObjectPath ExternalSourceDefaultMedia; // 0x50(0x20)
	struct FDirectoryPath ExternalSourceStagingDirectory; // 0x70(0x10)
	char pad_80[0x18]; // 0x80(0x18)
};

