// BlueprintGeneratedClass ModifyObservePlayerActionTraits.ModifyObservePlayerActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UModifyObservePlayerActionTraits_C : UActionTraits {
};

