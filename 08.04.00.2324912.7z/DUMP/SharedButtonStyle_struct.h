// UserDefinedStruct SharedButtonStyle.SharedButtonStyle
// Size: 0x48 (Inherited: 0x00)
struct FSharedButtonStyle {
	struct FLinearColor BackgroundColor_2_BA973BC94AC9F8AC252C34BD4450263B; // 0x00(0x10)
	struct FLinearColor LabelColor_4_A03B98D948AA7759CB4B2DA7A90661D1; // 0x10(0x10)
	struct FLinearColor DisabledBackgroundColor_6_EB50AD2C4852D11D853BB5A0BCE0D454; // 0x20(0x10)
	struct UAkAudioEvent* AUD_Click_12_C86DC8EB425EED425BC55ABD5D69C9DC; // 0x30(0x08)
	struct UAkAudioEvent* AUD_HoverA_14_2DF682924FCF9618E1819D8466EE64D6; // 0x38(0x08)
	struct UAkAudioEvent* AUD_HoverB_15_2ADB07144A84ED2B256F52AA3412E93F; // 0x40(0x08)
};

