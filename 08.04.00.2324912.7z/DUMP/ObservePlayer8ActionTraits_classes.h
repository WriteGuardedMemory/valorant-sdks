// BlueprintGeneratedClass ObservePlayer8ActionTraits.ObservePlayer8ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UObservePlayer8ActionTraits_C : UActionTraits {
};

