// BlueprintGeneratedClass OpenCommMenuActionTraits.OpenCommMenuActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UOpenCommMenuActionTraits_C : UActionTraits {
};

