// BlueprintGeneratedClass SecondHalfUltAlternateActionTraits.SecondHalfUltAlternateActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct USecondHalfUltAlternateActionTraits_C : UActionTraits {
};

