// BlueprintGeneratedClass OpenCommTree1ActionTraits.OpenCommTree1ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UOpenCommTree1ActionTraits_C : UActionTraits {
};

