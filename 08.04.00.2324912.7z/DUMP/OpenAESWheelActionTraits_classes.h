// BlueprintGeneratedClass OpenAESWheelActionTraits.OpenAESWheelActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UOpenAESWheelActionTraits_C : UActionTraits {
};

