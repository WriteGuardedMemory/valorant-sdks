// BlueprintGeneratedClass GamepadWidgetFunctionLibrary.GamepadWidgetFunctionLibrary_C
// Size: 0x30 (Inherited: 0x30)
struct UGamepadWidgetFunctionLibrary_C : UBlueprintFunctionLibrary {

	void GetGamepadUIData(struct UObject* __WorldContext, struct UGamepadUIData_Type_C*& GamepadUIData); // Function GamepadWidgetFunctionLibrary.GamepadWidgetFunctionLibrary_C.GetGamepadUIData // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x4125d60
};

