// BlueprintGeneratedClass ObservePlayer4ActionTraits.ObservePlayer4ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UObservePlayer4ActionTraits_C : UActionTraits {
};

