// BlueprintGeneratedClass CommMenuOption6ActionTraits.CommMenuOption6ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCommMenuOption6ActionTraits_C : UActionTraits {
};

