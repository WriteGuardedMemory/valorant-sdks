// BlueprintGeneratedClass ToggleMinimapActionTraits.ToggleMinimapActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UToggleMinimapActionTraits_C : UActionTraits {
};

