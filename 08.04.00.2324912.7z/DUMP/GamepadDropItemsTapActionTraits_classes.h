// BlueprintGeneratedClass GamepadDropItemsTapActionTraits.GamepadDropItemsTapActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UGamepadDropItemsTapActionTraits_C : UActionTraits {
};

