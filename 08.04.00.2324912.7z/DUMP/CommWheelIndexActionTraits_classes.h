// BlueprintGeneratedClass CommWheelIndexActionTraits.CommWheelIndexActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCommWheelIndexActionTraits_C : UActionTraits {
};

