// BlueprintGeneratedClass ClientNavUpActionTraits.ClientNavUpActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UClientNavUpActionTraits_C : UActionTraits {
};

