// ScriptStruct UObjectPlugin.MyPluginStruct
// Size: 0x10 (Inherited: 0x00)
struct FMyPluginStruct {
	struct FString TestString; // 0x00(0x10)
};

