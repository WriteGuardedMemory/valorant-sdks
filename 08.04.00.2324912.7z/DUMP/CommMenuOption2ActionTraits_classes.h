// BlueprintGeneratedClass CommMenuOption2ActionTraits.CommMenuOption2ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCommMenuOption2ActionTraits_C : UActionTraits {
};

