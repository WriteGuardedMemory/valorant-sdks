// BlueprintGeneratedClass ObservePlayer5ActionTraits.ObservePlayer5ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UObservePlayer5ActionTraits_C : UActionTraits {
};

