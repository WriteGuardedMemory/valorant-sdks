// BlueprintGeneratedClass EquipLastUsedActionTraits.EquipLastUsedActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UEquipLastUsedActionTraits_C : UActionTraits {
};

