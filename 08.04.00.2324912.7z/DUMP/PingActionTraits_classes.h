// BlueprintGeneratedClass PingActionTraits.PingActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UPingActionTraits_C : UActionTraits {
};

