// Class JsonUtilities.JsonUtilitiesDummyObject
// Size: 0x30 (Inherited: 0x30)
struct UJsonUtilitiesDummyObject : UObject {
};

