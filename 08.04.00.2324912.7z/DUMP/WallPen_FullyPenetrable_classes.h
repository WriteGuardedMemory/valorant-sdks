// BlueprintGeneratedClass WallPen_FullyPenetrable.WallPen_FullyPenetrable_C
// Size: 0x48 (Inherited: 0x48)
struct UWallPen_FullyPenetrable_C : UAresWallPenetration {
};

