// Class UmbraCulling.UmbraPrecomputedData
// Size: 0x40 (Inherited: 0x30)
struct UUmbraPrecomputedData : UAssetUserData {
	struct TArray<uint32_t> Data; // 0x30(0x10)
};

