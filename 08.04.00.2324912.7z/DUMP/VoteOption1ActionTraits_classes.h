// BlueprintGeneratedClass VoteOption1ActionTraits.VoteOption1ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UVoteOption1ActionTraits_C : UActionTraits {
};

