// BlueprintGeneratedClass WallPen_Moderate.WallPen_Moderate_C
// Size: 0x48 (Inherited: 0x48)
struct UWallPen_Moderate_C : UAresWallPenetration {
};

