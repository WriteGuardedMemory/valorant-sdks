// BlueprintGeneratedClass ToggleJanusUIActionTraits.ToggleJanusUIActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UToggleJanusUIActionTraits_C : UActionTraits {
};

