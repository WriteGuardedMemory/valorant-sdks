// BlueprintGeneratedClass CountdownPingActionTraits.CountdownPingActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCountdownPingActionTraits_C : UActionTraits {
};

