// BlueprintGeneratedClass ToggleCharacterAbilityHUDActionTraits.ToggleCharacterAbilityHUDActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UToggleCharacterAbilityHUDActionTraits_C : UActionTraits {
};

