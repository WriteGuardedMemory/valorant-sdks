// BlueprintGeneratedClass ClientNavDownActionTraits.ClientNavDownActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UClientNavDownActionTraits_C : UActionTraits {
};

