// BlueprintGeneratedClass OpenMegamapActionTraits.OpenMegamapActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UOpenMegamapActionTraits_C : UActionTraits {
};

