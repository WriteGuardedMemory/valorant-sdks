// Class PropertyAccess.PropertyAccess
// Size: 0x30 (Inherited: 0x30)
struct UPropertyAccess : UInterface {
};

// Class PropertyAccess.PropertyEventBroadcaster
// Size: 0x30 (Inherited: 0x30)
struct UPropertyEventBroadcaster : UInterface {
};

// Class PropertyAccess.PropertyEventSubscriber
// Size: 0x30 (Inherited: 0x30)
struct UPropertyEventSubscriber : UInterface {
};

