// BlueprintGeneratedClass ObserverFollowNextActionTraits.ObserverFollowNextActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UObserverFollowNextActionTraits_C : UActionTraits {
};

