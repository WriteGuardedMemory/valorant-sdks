// BlueprintGeneratedClass ModalNotificationColors.ModalNotificationColors_C
// Size: 0x56 (Inherited: 0x50)
struct UModalNotificationColors_C : UAresBasePrimaryDataAsset {
	enum class ButtonColors ConfirmationButtonColor; // 0x50(0x01)
	enum class ButtonColors MiddleButtonColor; // 0x51(0x01)
	enum class ButtonColors CancelButtonColor; // 0x52(0x01)
	enum class TextColors TitleTextColor; // 0x53(0x01)
	enum class FillColors FillColor; // 0x54(0x01)
	enum class TextColors MessageTextColor; // 0x55(0x01)
};

