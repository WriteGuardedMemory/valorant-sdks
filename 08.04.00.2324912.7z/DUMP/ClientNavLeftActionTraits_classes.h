// BlueprintGeneratedClass ClientNavLeftActionTraits.ClientNavLeftActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UClientNavLeftActionTraits_C : UActionTraits {
};

