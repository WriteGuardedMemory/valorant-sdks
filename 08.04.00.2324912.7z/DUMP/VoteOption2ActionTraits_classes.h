// BlueprintGeneratedClass VoteOption2ActionTraits.VoteOption2ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UVoteOption2ActionTraits_C : UActionTraits {
};

