// BlueprintGeneratedClass GamepadWeaponSwapHoldActionTraits.GamepadWeaponSwapHoldActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UGamepadWeaponSwapHoldActionTraits_C : UActionTraits {
};

