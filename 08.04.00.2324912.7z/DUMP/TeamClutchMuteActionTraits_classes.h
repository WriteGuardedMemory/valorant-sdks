// BlueprintGeneratedClass TeamClutchMuteActionTraits.TeamClutchMuteActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UTeamClutchMuteActionTraits_C : UActionTraits {
};

