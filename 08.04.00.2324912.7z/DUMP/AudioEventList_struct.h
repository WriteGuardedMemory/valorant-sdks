// UserDefinedStruct AudioEventList.AudioEventList
// Size: 0x10 (Inherited: 0x00)
struct FAudioEventList {
	struct TArray<struct UAkAudioEvent*> EventList_3_BD1D886C4461535F3DDFB59B319F9C1E; // 0x00(0x10)
};

