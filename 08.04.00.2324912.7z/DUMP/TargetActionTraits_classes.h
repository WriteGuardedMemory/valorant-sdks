// BlueprintGeneratedClass TargetActionTraits.TargetActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UTargetActionTraits_C : UActionTraits {
};

