// Class AnimationCore.AnimationDataSourceRegistry
// Size: 0x80 (Inherited: 0x30)
struct UAnimationDataSourceRegistry : UObject {
	struct TMap<struct FName, struct TWeakObjectPtr<struct UObject>> DataSources; // 0x30(0x50)
};

