// Class ImageWriteQueue.ImageWriteBlueprintLibrary
// Size: 0x30 (Inherited: 0x30)
struct UImageWriteBlueprintLibrary : UBlueprintFunctionLibrary {

	void ExportToDisk(struct UTexture* Texture, struct FString Filename, struct FImageWriteOptions& OPTIONS); // Function ImageWriteQueue.ImageWriteBlueprintLibrary.ExportToDisk // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x44df270
};

