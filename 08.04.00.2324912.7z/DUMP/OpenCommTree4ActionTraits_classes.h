// BlueprintGeneratedClass OpenCommTree4ActionTraits.OpenCommTree4ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UOpenCommTree4ActionTraits_C : UActionTraits {
};

