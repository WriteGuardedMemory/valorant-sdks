// BlueprintGeneratedClass GamepadMoveDownActionTraits.GamepadMoveDownActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UGamepadMoveDownActionTraits_C : UActionTraits {
};

