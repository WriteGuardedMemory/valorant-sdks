// BlueprintGeneratedClass VOEmoteYesActionTraits.VOEmoteYesActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UVOEmoteYesActionTraits_C : UActionTraits {
};

