// BlueprintGeneratedClass DropEquippableActionTraits.DropEquippableActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UDropEquippableActionTraits_C : UActionTraits {
};

