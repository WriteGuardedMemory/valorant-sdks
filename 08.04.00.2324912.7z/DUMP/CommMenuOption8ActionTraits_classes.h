// BlueprintGeneratedClass CommMenuOption8ActionTraits.CommMenuOption8ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCommMenuOption8ActionTraits_C : UActionTraits {
};

