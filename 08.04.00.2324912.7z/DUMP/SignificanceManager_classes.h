// Class SignificanceManager.SignificanceManager
// Size: 0x130 (Inherited: 0x30)
struct USignificanceManager : UObject {
	char pad_30[0xe0]; // 0x30(0xe0)
	struct FSoftClassPath SignificanceManagerClassName; // 0x110(0x20)
};

