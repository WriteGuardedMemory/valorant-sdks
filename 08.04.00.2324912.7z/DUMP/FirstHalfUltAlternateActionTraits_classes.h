// BlueprintGeneratedClass FirstHalfUltAlternateActionTraits.FirstHalfUltAlternateActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UFirstHalfUltAlternateActionTraits_C : UActionTraits {
};

