// BlueprintGeneratedClass ObservePlayer1ActionTraits.ObservePlayer1ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UObservePlayer1ActionTraits_C : UActionTraits {
};

