// BlueprintGeneratedClass VoteOption0ActionTraits.VoteOption0ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UVoteOption0ActionTraits_C : UActionTraits {
};

