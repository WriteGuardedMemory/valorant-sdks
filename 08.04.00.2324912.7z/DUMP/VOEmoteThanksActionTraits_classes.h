// BlueprintGeneratedClass VOEmoteThanksActionTraits.VOEmoteThanksActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UVOEmoteThanksActionTraits_C : UActionTraits {
};

