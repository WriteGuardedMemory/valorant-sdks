// BlueprintGeneratedClass OnMywayPingActionTraits.OnMywayPingActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UOnMywayPingActionTraits_C : UActionTraits {
};

