// UserDefinedStruct Struct_AttenuationInformation.Struct_AttenuationInformation
// Size: 0x15 (Inherited: 0x00)
struct FStruct_AttenuationInformation {
	struct UAkComponent* AkComponent_14_106F310C43CDB01FD0A8DEBFDE517218; // 0x00(0x08)
	struct AActor* OwningActor_17_C26E53BD408A01E63122CDB78028F7CC; // 0x08(0x08)
	float Radius_5_E6DBEEBE41FF7D345D977287C3DB0054; // 0x10(0x04)
	enum class Enum_AttenuationVisualization Type_12_5BA7C0944FAC16BF24CA378849F7DB22; // 0x14(0x01)
};

