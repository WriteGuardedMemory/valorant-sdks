// BlueprintGeneratedClass EmojiMapping.EmojiMapping_C
// Size: 0x80 (Inherited: 0x80)
struct UEmojiMapping_C : UEmojiMapping {
};

