// BlueprintGeneratedClass PrimaryTriggerActionTraits.PrimaryTriggerActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UPrimaryTriggerActionTraits_C : UActionTraits {
};

