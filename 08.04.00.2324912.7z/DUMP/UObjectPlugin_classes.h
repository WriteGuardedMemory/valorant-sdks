// Class UObjectPlugin.MyPluginObject
// Size: 0x40 (Inherited: 0x30)
struct UMyPluginObject : UObject {
	struct FMyPluginStruct MyStruct; // 0x30(0x10)
};

