// WidgetBlueprintGeneratedClass InitDirectConnect.InitDirectConnect_C
// Size: 0x2d8 (Inherited: 0x2c8)
struct UInitDirectConnect_C : UUserWidget {
	struct UBuildNumberDisplay_C* BuildNumberDisplay; // 0x2c8(0x08)
	struct UScaleBox* DirectConnectScaleBox; // 0x2d0(0x08)
};

