// BlueprintGeneratedClass SprayActionTraits.SprayActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct USprayActionTraits_C : UActionTraits {
};

