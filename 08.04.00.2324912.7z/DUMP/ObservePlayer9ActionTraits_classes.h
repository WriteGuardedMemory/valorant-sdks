// BlueprintGeneratedClass ObservePlayer9ActionTraits.ObservePlayer9ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UObservePlayer9ActionTraits_C : UActionTraits {
};

