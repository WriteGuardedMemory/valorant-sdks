// BlueprintGeneratedClass CommMenuOption9ActionTraits.CommMenuOption9ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCommMenuOption9ActionTraits_C : UActionTraits {
};

