// BlueprintGeneratedClass GamepadWeaponSwapPressActionTraits.GamepadWeaponSwapPressActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UGamepadWeaponSwapPressActionTraits_C : UActionTraits {
};

