// BlueprintGeneratedClass CommMenuOption7ActionTraits.CommMenuOption7ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCommMenuOption7ActionTraits_C : UActionTraits {
};

