// BlueprintGeneratedClass ObservePlayer10ActionTraits.ObservePlayer10ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UObservePlayer10ActionTraits_C : UActionTraits {
};

