// BlueprintGeneratedClass ToggleMapActionTraits.ToggleMapActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UToggleMapActionTraits_C : UActionTraits {
};

