// BlueprintGeneratedClass ObservePlayer7ActionTraits.ObservePlayer7ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UObservePlayer7ActionTraits_C : UActionTraits {
};

