// BlueprintGeneratedClass Activate_UltimateActionTraits.Activate_UltimateActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UActivate_UltimateActionTraits_C : UActionTraits {
};

