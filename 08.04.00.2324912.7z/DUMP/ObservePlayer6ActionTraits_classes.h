// BlueprintGeneratedClass ObservePlayer6ActionTraits.ObservePlayer6ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UObservePlayer6ActionTraits_C : UActionTraits {
};

