// BlueprintGeneratedClass UseGenericMapObjectActionTraits.UseGenericMapObjectActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UUseGenericMapObjectActionTraits_C : UActionTraits {
};

