// BlueprintGeneratedClass WatchingHerePingActionTraits.WatchingHerePingActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UWatchingHerePingActionTraits_C : UActionTraits {
};

