// Class EsportsEvents.EsportsGameDataEventReceiver
// Size: 0x58 (Inherited: 0x30)
struct UEsportsGameDataEventReceiver : UBaseGameDataEventReceiver {
	char pad_30[0x18]; // 0x30(0x18)
	struct UGameDataExporter* GameDataExporter; // 0x48(0x08)
	char pad_50[0x8]; // 0x50(0x08)
};

