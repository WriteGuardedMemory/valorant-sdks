// Class WwiseFileHandler.WwiseExternalSourceStatics
// Size: 0x30 (Inherited: 0x30)
struct UWwiseExternalSourceStatics : UBlueprintFunctionLibrary {

	void SetExternalSourceMediaWithIds(struct FAkUniqueID ExternalSourceCookie, int32_t MediaId); // Function WwiseFileHandler.WwiseExternalSourceStatics.SetExternalSourceMediaWithIds // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x24f46d0
	void SetExternalSourceMediaByName(struct FString ExternalSourceName, struct FString MediaName); // Function WwiseFileHandler.WwiseExternalSourceStatics.SetExternalSourceMediaByName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x24f45d0
	void SetExternalSourceMediaById(struct FString ExternalSourceName, int32_t MediaId); // Function WwiseFileHandler.WwiseExternalSourceStatics.SetExternalSourceMediaById // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x24f44f0
};

