// BlueprintGeneratedClass VOEmoteNoActionTraits.VOEmoteNoActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UVOEmoteNoActionTraits_C : UActionTraits {
};

