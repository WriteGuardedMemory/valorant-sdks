// BlueprintGeneratedClass Init.Init_C
// Size: 0x3e0 (Inherited: 0x3e0)
struct AInit_C : ALevelScriptActor {
};

