// BlueprintGeneratedClass JanusSpdUpActionTraits.JanusSpdUpActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UJanusSpdUpActionTraits_C : UActionTraits {
};

