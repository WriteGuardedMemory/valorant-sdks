// UserDefinedEnum SharedBackButtonTypes.SharedBackButtonTypes
enum class SharedBackButtonTypes : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	SharedBackButtonTypes_MAX = 3
};

