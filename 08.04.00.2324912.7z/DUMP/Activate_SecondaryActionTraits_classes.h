// BlueprintGeneratedClass Activate_SecondaryActionTraits.Activate_SecondaryActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UActivate_SecondaryActionTraits_C : UActionTraits {
};

