// BlueprintGeneratedClass PregamePlayerController.PregamePlayerController_C
// Size: 0xa08 (Inherited: 0xa08)
struct APregamePlayerController_C : APregamePlayerController {
};

