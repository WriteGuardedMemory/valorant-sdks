// BlueprintGeneratedClass PartyPTTActionTraits.PartyPTTActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UPartyPTTActionTraits_C : UActionTraits {
};

