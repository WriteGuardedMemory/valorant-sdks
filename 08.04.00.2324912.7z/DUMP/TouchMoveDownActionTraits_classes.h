// BlueprintGeneratedClass TouchMoveDownActionTraits.TouchMoveDownActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UTouchMoveDownActionTraits_C : UActionTraits {
};

