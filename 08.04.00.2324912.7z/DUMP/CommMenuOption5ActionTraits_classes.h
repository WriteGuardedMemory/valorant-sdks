// BlueprintGeneratedClass CommMenuOption5ActionTraits.CommMenuOption5ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UCommMenuOption5ActionTraits_C : UActionTraits {
};

