// ScriptStruct ActorLayerUtilities.ActorLayer
// Size: 0x0c (Inherited: 0x00)
struct FActorLayer {
	struct FName Name; // 0x00(0x0c)
};

