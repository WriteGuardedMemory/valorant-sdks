// Enum PlatformUI.LoadingIndicatorType
enum class LoadingIndicatorType : uint8 {
	INDETERMINATE_LOADER = 0,
	PROGRESS_BAR = 1,
	LoadingIndicatorType_MAX = 2
};

