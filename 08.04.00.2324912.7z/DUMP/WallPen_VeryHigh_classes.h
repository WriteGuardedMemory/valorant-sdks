// BlueprintGeneratedClass WallPen_VeryHigh.WallPen_VeryHigh_C
// Size: 0x48 (Inherited: 0x48)
struct UWallPen_VeryHigh_C : UAresWallPenetration {
};

